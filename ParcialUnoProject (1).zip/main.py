nom = "Daniela Perez"
nac = 1989
print("Hola,",nom , '. En el año 2025 tendrás', 2025-nac, "años")

print("-------------------------------------- ")

prog = "Programar en Python es increíble"
letra = "p " 
numL = len(letra)

print('La letra "p" aparece', numL , 'veces en la frase.')

print("------------------------------------------ ")

nombres = "Juan Perez-María Gomez-Pedro Ruiz"

primer = "Juan perez "
segundo = "María Gomez "
tercer = "Pedo Ruiz "
print("Primer nombre: ", primer)
print("Segundo nombre: ", segundo)
print("tercer nombre: ", tercer)
     

